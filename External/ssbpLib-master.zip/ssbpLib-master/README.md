### sspbLib

ドキュメントはこちらです。  
https://github.com/SpriteStudio/sspbLib/wiki
